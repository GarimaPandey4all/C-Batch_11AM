#include <iostream>

using namespace std;

int main()
{
    int i,sum=0, a[5];

    cout<<"Enter value in array";
    for(i=0; i<5; i++)
    cin>>a[i];

    for(i=0; i<5; i++)
    sum += a[i]; //sum = sum + a[i];

    cout<<"Sum is:"<<sum<<endl;
    return 0;
}
