#include <iostream>

using namespace std;

int main()
{
    int number, remainder;

    cout<<"Enter any Number:";
    cin>>number;

    remainder = number % 2;

    (remainder == 0) ? cout<<"Number is Even" : cout<<"Number is Odd";

//    if(remainder == 0)
//        cout<<"Number is Even";
//
//    else
//        cout<<"Number is Odd";

    return 0;
}
