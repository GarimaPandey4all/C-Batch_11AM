#include <iostream>

using namespace std;

int main()
{
    int marks[10], i, sum=0, percentage;

    cout<<"Enter Ten Marks:\n";
    for(i=0; i<10; i++)
    cin>>marks[i];

    for(i=0; i<10; i++)
    sum += marks[i];

    cout<<"Sum is:"<<sum<<endl;

    percentage = (sum /10);

    cout<<"Percentage is:"<<percentage<<endl;

    if(percentage >= 50 && percentage <= 60)
        cout<<"\nD Grade";

    else if(percentage >= 60 && percentage <= 70)
        cout<<"\nC Grade";

    else if(percentage >= 70 && percentage <= 80)
        cout<<"\nB Grade";

    else if(percentage >= 80 && percentage <= 100)
        cout<<"\nA Grade";

    else
        cout<<"\nOtherwise Fail";

    return 0;
}
