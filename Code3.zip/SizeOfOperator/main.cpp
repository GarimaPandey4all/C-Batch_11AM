#include <iostream>

using namespace std;

int main()
{
    int a;
    char b;
    float c;
    double d;
    long double e;
    short int f;

    cout<<"SizeOF int:"<<sizeof(a)<< endl;
    cout<<"SizeOF char:"<<sizeof(b)<< endl;
    cout<<"SizeOF float:"<<sizeof(c)<< endl;
    cout<<"SizeOF double:"<<sizeof(d)<< endl;
    cout<<"SizeOF long double:"<<sizeof(e)<< endl;
    cout<<"SizeOF short int:"<<sizeof(f)<< endl;

    return 0;
}
