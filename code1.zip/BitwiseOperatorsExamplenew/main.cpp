#include <iostream>

using namespace std;

int main()
{
    int A, B, C;

    cout<<"Enter any value for A:";
    cin>>A;

    cout<<"Enter any value for B:";
    cin>>B;

    //Bitwise And Operator

    C = A & B;

    cout<<"\nResult of A & B:"<<C<<endl;

    //Bitwise Or Operator

    C = A | B;

    cout<<"\nResult of A | B:"<<C<<endl;

    //Bitwise Not Operator

    if(~(A & B))
        cout<<"This is ~(A & B)";

    return 0;
}
