#include <iostream>

using namespace std;

int main()
{
    int A, B;

    cout<<"Enter value for A:";
    cin>>A;

    cout<<"Enter value for B:";
    cin>>B;

    //Logical Operators

    if(A && B)
        cout<<"\nThis is A && B";

    if(A || B)
        cout<<"\nThis is A || B";

    if(!(A && B))
        cout<<"\nThis is !(A && B)";

    if(!A)
        cout<<"\nThis is !A";

    if(!B)
        cout<<"\nThis is !B\n";

    return 0;
}
