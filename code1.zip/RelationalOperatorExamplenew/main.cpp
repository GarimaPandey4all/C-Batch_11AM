#include <iostream>

using namespace std;

int main()
{
    int A, B;

    cout<<"Enter value for A:";
    cin>>A;

    cout<<"Enter value for B:";
    cin>>B;

    //Relational Operators

    if(A==B)
        cout<<"\nA is equal to B";

    if(A > B)
        cout<<"\nA is greater than B";

    if(A < B)
        cout<<"\nB is greater than A";

    if(A >= B)
        cout<<"\nA is greater than and equal to B";

    if(A <= B)
        cout<<"\nB is greater than and equal to A";

    if(A != B)
        cout<<"\nA is not equal to B";

    return 0;
}
