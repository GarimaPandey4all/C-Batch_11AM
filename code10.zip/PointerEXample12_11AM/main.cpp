#include <iostream>

using namespace std;

int main()
{
    const int value = 10; //normal variable i equal to constant

    const int *const pvalue = &value; //value and address can;t be changed

    //value = 20; //constant variable

    //*pvalue = 20; //pointer to a constant

    int item = 20;

    pvalue = &item; //pointer constant

    return 0;
}
