#include <iostream>

using namespace std;

int main()
{
    int value = 0;

    const int *pvalue = NULL; //value can't be changed //pointer to a constant

    value = 100;

    pvalue = &value;

    *pvalue = 10;

    return 0;
}
