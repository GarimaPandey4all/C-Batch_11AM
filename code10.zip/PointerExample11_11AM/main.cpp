#include <iostream>

using namespace std;

int main()
{
    int value = 0;

    int *const pvalue = &value; //address can't be changed //pointer constant

    value = 100;

    *pvalue = 10;

    int item = 20;

    pvalue = &item; //error: assignment read-only variable

    return 0;
}
