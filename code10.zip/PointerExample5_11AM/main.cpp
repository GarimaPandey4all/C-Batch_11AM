#include <iostream>

using namespace std;

int main()
{
    int number =10;
    char ch = 'A';

    int *pnumber = &number;

    char *pch = &ch;

    cout<<"SizeOF: "<<sizeof(pnumber)<<endl;

    cout<<"SizeOF: "<<sizeof(*pnumber)<<endl;

    cout<<"SizeOF: "<<sizeof(pch)<<endl;

    cout<<"SizeOF: "<<sizeof(*pch);

    return 0;
}
