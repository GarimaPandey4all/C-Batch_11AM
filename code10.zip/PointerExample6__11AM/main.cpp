#include <iostream>

using namespace std;

int main()
{
    int number = 0;

    int *pnumber = NULL;

    number = 10;

    pnumber = &number;

    *pnumber += 25; //*pnumber = *pnumber + 25;

    cout<<"Pnumber is: "<<*pnumber;

    return 0;
}
