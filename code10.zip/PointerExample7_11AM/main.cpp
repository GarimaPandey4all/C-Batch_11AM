#include <iostream>

using namespace std;

int main()
{
    long num1 = 0L;
    long num2 = 0L;

    long *pnum = NULL;

    pnum = &num1;
    *pnum = 2L;
    ++num2;
    num2 += *pnum;

    pnum = &num2;
    ++*pnum;

    cout<<"num1="<<num1<<" num2="<<num2<<" *pnum="<<*pnum<<" *pnum + num2="<<*pnum+num2;

    return 0;
}
