#include <iostream>

using namespace std;

int main()
{
    int value=0;

    int *pvalue=NULL;

    pvalue = &value;

    cout<<"Enter any integer:";
    cin>>*pvalue;

    cout<<"Value is: "<<value;

    return 0;
}
