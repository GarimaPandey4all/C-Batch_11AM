#include <iostream>

using namespace std;

int main()
{
    int *pt;

    *pt= 5; //error: derefenced unintialized pointer

    return 0;
}
