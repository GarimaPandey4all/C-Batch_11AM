#include <iostream>

using namespace std;

int main()
{
    int matrix[10][10], i, j, rows, columns;

    cout<<"Enter any number of rows:";
    cin>>rows;

    cout<<"Enter any number of columns:";
    cin>>columns;

    cout<<"Enter "<<rows*columns<<" Integers:"<<endl;
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cin>>matrix[i][j];
        }
    }

    cout<<"Values in Matrix are:"<<endl;
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<matrix[i][j]<<"\t";
        }
        cout<<endl;
    }

    cout<<"Principal Diagonal matrix values are:"<<endl;
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(i == j)
            {
                cout<<matrix[i][j]<<"   ";
            }
        }
    }

    return 0;
}
