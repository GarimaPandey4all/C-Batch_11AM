#include <iostream>

using namespace std;

int main()
{
    int matrix[10][10], i, j, rows, columns, temp[10][10], count =1;

    cout<<"Enter any number of rows:";
    cin>>rows;

    cout<<"Enter any number of columns:";
    cin>>columns;

    cout<<"Enter "<<rows*columns<<" Integers:"<<endl;
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cin>>matrix[i][j];
        }
    }

    cout<<"Values in Original Matrix are:"<<endl;
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<matrix[i][j]<<"\t";
        }
        cout<<endl;
    }

    //Transpose of a matrix
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            temp[j][i] = matrix[i][j];
        }
    }

    cout<<"Values in Transpose Matrix are:"<<endl;
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<temp[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(matrix[i][j] != temp[i][j])
            {
                ++count;
                break;
            }
        }
    }

    if(count == 1)
        cout<<"Matrix is Symmetric.";
    else
        cout<<"Matrix is Not Symmetric.";

    return 0;
}
