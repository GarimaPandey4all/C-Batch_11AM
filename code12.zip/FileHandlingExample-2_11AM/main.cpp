#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    char ch;

    ifstream infile("Test.txt", ios::in); //read mode

    while(infile)
    {
        infile.get(ch); //take character from  a file
        cout<<ch;
    }

    infile.close();

    return 0;
}
