#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ofstream outfile("Test.txt", ios::out);

    outfile<<"Garima Pandey"<<endl;
    outfile<<25<<endl;
    outfile<<"Welcome Garima Pandey."<<endl;


    outfile<<"Jyoti"<<endl;
    outfile<<25<<endl;
    outfile<<"Welcome Jyoti."<<endl;

    outfile.close();

    return 0;
}
