#include <stdio.h>

int main()
{
    int a=10, b=0;

    printf("Division is:%d", a/b);

    return 0;
}
