#include <iostream>

using namespace std;

int main()
{
    int a=10, b=0;

    cout<<"Division is:"<<a/b;

    return 0;
}
