#include <iostream>

using namespace std;

void Myfunc()
{
    throw 10;
}

int main()
{
    try
    {
        //throw exception...

        Myfunc(); //function calling

        cout<<"Try Block.";
    }

    catch(...)
    {
        cout<<"Exception here...";
    }

//    catch(int e)
//    {
//        cout<<"Value is:"<<e<<endl;
//    }

    return 0;
}
