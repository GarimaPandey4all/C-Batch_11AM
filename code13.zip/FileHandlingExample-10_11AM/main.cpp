#include <iostream>
#include <fstream>


using namespace std;

int main()
{
    fstream file;

    file.open("Test.txt", ios::out | ios::in);

    file<<"My Name is Garima Pandey.";

    file.seekg(11, ios::beg);

    char A[11];

    file.read(A, 13);

    A[13] = 0;

    cout<<A<<endl;

    cout<<"Current position of pointer is:"<<file.tellp();

    file.close();

    return 0;
}
