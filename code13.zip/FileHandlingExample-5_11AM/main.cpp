#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ofstream outfile("Text.txt", ios::trunc);

//    outfile<<"Garima"<<endl;
//    outfile<<"Pandey"<<endl;
//    outfile<<25<<endl;
//    outfile<<"Welcome Garima Pandey."<<endl;

    outfile<<"Jyoti"<<endl;
    outfile<<"Kohli"<<endl;
    outfile<<25<<endl;
    outfile<<"Welcome Jyoti Kohli."<<endl;

    return 0;
}
