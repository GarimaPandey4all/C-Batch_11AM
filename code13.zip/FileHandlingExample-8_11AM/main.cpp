#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    int position;

    fstream file;

    file.open("Test.txt");

    //Write content in a file
    file.write("This is an apple.", 17); //This is a sample.

    position = file.tellp();

    //set pointer position
    file.seekp(position - 8); //17-8 = 9

    file.write(" sam", 4);

    file.close();

    return 0;
}
