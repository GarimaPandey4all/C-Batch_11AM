#include <iostream>

using namespace std;

template <class T>
class Calculator
{
private:
    T a, b;

public:
    Calculator(T x, T y)
    {
        a = x;
        b = y;
    }

    void displayResult()
    {
        cout<<"Addition is:"<<a+b<<endl;
        cout<<"Subtraction is:"<<a-b<<endl;
        cout<<"Multiplication is:"<<a*b<<endl;
        cout<<"Division is:"<<a/b<<endl<<endl<<endl;
    }
};

int main()
{
    Calculator<int> C1(10, 20);
    Calculator<float> C2(30.7, 40.8);

    C1.displayResult();
    C2.displayResult();

    return 0;
}
