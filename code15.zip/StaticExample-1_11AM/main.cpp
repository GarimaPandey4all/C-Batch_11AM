#include <iostream>

using namespace std;

class Student
{
private:
    int rollno; //instance variable
    static int marks; //Static variable/ class member variable

public:
    void setData(int r)
    {
        rollno = r;
    }

    void showData()
    {
        cout<<"Rollno is:"<<rollno<<endl;
        cout<<"Marks is:"<<marks<<endl;
    }
};

int Student :: marks = 525; //initialization/definition of instance variable

int main()
{
    Student S1;

    S1.setData(4);
    S1.showData();
    return 0;
}
