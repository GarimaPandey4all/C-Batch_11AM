#include <iostream>

using namespace std;
//static variable inside function

class counter
{
public:
    void updateCount()
    {
        static int Count; //same as static int Count = 0;
        cout<<Count++<<" ";
    }
};

int main()
{
    counter c;

    for(int i=0; i<5; i++)
    {
        c.updateCount();
    }

    return 0;
}
