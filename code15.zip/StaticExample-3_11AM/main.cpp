#include <iostream>

using namespace std;

//Static variable inside function but without using class

void updateCount()
{
    static int Count;
    cout<<Count++<<endl;
}

int main()
{
    for(int i=0; i<5; i++)
        updateCount();
    return 0;
}
