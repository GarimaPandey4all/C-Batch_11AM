#include <iostream>

using namespace std;

//Static Data Member in class

class Employee
{
public:
    static int age;

    Employee()
    {
        cout<<"Age is:"<<age<<endl; //one way to print static variable
    }
};

int Employee :: age = 25;

int main()
{
    Employee obj;

    cout<<"Age is:"<<obj.age; //second way to print static variable.

    return 0;
}
