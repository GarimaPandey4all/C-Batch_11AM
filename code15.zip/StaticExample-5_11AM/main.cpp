#include <iostream>

using namespace std;

//normal variable inside function but without using class

void updateCount()
{
    int Count = 0;
    cout<<Count++<<endl;
}

int main()
{
    for(int i=0; i<5; i++)
        updateCount();
    return 0;
}
