#include <iostream>

using namespace std;

class Demo
{
public:
    static void func()
    {
        cout<<"This is Static member function block.";
    }
};

int main()
{
    Demo :: func(); //calling member function directly with class name
    return 0;
}
