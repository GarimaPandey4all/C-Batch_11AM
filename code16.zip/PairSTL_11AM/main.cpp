#include <iostream>
//#include <pair>

using namespace std;

class student
{
private:
    string name;
    int age;

public:
    void SetStudent(string s, int a)
    {
        name = s;
        age = a;
    }

    void ShowData()
    {
        cout<<"Name of student is:"<<name<<endl;
        cout<<"Age of student is:"<<age<<endl;
    }
};


int main()
{
    student s1;

    s1.SetStudent("Garima", 24);

    pair <string, int> p1;
    pair <string, string> p2;
    pair <string, float> p3;
    pair <int, student> p4;

    //Insert: make_pair

    p1 = make_pair("Jyoti", 23);

    p2 = make_pair("Jyoti", "Kohli");

    p3 = make_pair("C++", 3.0f);

    p4 = make_pair(25, s1);

    //Accessing values from the pair

    cout<<"Pair 1:"<<p1.first<<" "<<p1.second<<endl;

    cout<<"Pair 2:"<<p2.first<<" "<<p2.second<<endl;

    cout<<"Pair 3:"<<p3.first<<" "<<p3.second<<endl;

    cout<<"Pair 4:"<<p4.first<<endl;

    //s2 = p4.second
    //s1 = s2;
    student s2 = p4.second;

    s2.ShowData();

    //Also check relational operators

    if(p1.first != p2.first)
        cout<<"P1 is not equal to P2.";

    return 0;
}
