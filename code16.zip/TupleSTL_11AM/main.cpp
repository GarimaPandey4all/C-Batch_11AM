#include <iostream>
#include <tuple>

using namespace std;

//Just like an pair , we can pair two heterogeneous objects in
//tuple we can pair multiple objects

//tuple <T1, T2, T3> tuple1;

//Example:

//tuple <string, int, int> t1;

//insert into a tuple: make_tuple

int main()
{
    tuple <string, int, int> t1;

    //insert in tuple

    t1 = make_tuple("New Delhi", 10, 25);

    //Accessing values from the tuple

    cout<<"Tuple 1"<<get<0>(t1)<<" ";
    cout<<get<1>(t1)<<" ";
    cout<<get<2>(t1)<<" ";

    return 0;
}
