#include <iostream>
#include <map>

using namespace std;

int main()
{
    map <int, string> customer;

    customer[100] = "Garima";
    customer[123] = "Jyoti";
    customer[145] = "Dilip";
    customer[101] = "Rahul";

    //Or second way:

    map <int, string> c2 {{100, "Garima"}, {123, "Jyoti"}, {145, "Dilip"}, {101, "Rahul"}};

    return 0;
}
