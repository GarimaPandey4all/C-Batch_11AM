#include <iostream>
#include <map>

using namespace std;

int main()
{
    map <int, string> customer;

    customer[100] = "Garima";
    customer[123] = "Jyoti";
    customer[145] = "Dilip";
    customer[101] = "Rahul";

    //Or second way:

    map <int, string> c2 {{100, "Garima"}, {123, "Jyoti"}, {145, "Dilip"}, {101, "Rahul"}};

    //Accessing values from the map: first way

    cout<<"Customer 1:"<<customer[100]<<endl;
    cout<<"Customer 1:"<<customer[123]<<endl;
    cout<<"Customer 1:"<<customer[145]<<endl;
    cout<<"Customer 1:"<<customer[101]<<endl;

    //at()

    cout<<customer.at(145)<<endl;


    //Accessing values from the map: second way

    map<int, string> :: iterator p = c2.begin();

    while( p != c2.end())
    {
        cout<<p->first<<endl;
        cout<<p->second<<endl;
        ++p;
    }

    cout<<"Total number of elements:"<<c2.size()<<endl;

    cout<<"empty is:"<<c2.empty();


    return 0;
}
