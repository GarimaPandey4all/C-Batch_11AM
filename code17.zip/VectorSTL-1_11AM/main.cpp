#include <iostream>
#include <vector>

using namespace std;

int main()
{
    //vector <int> V1; //declaration

    vector <string> V2{"Garima", "Joyti", "C++"};

    cout<<"Current Capacty is:"<<V2.capacity();

    return 0;
}
