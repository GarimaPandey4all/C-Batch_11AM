#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector <int> v1;

    for(int i=0; i<10;i++)
        v1.push_back(10*(i+1));

    cout<<"Values in vector are:\n";
    for(int i=0; i<v1.size();i++)
        cout<<v1[i]<<endl;

        cout<<endl<<endl;

    //insert at particular location

    vector <int> :: iterator ptr = v1.begin();

    v1.insert(ptr + 3, 35);

    for(int i=0; i<v1.size(); i++)
        cout<<v1[i]<<endl;


    v1.clear();

    cout<<"Size is:"<<v1.size();


    return 0;
}
