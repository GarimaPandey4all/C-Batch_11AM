#include <iostream>

using namespace std;

/*
    Friend Function:

    -friend function is not a member of a class to which it is a friend.

    -friend function is declared in the class with friend keyword.

    -It must be defined outside the class to which it is a friend.

    -friend function can access member of the class to which it is a friend.

    -friend function can't access members of the class directly.

*/

class complex
{
private:
    int a, b;

public:

    void setData(int x, int y)
    {
        a = x;
        b = y;
    }

    void showData()
    {
        cout<<"a:"<<a<<" b:"<<b<<endl;
    }

    friend void func(complex); //Friend declaration by using friend keyword

};


void func(complex c) //Friend function definition outside the class
{
    cout<<"Sum is:"<<c.a+c.b;
}

int main()
{
    complex obj; //object of class "complex"

    obj.setData(10, 30); //calling normal member function

    obj.showData();

    func(obj); //calling friend function by using class object
    return 0;
}
