#include <iostream>
#include <list>

using namespace std;

/*
    List in STL:

    - List supports a bidirectional linear list.

    - vector supports random access but a list can be accessed sequentially only.

    - List can be accessed front to back or back to front.

*/

int main()
{
    list <int> l1; //only creates a list

    list <string> l2 {"India", "Kathmandu"};

    list <int> l3 {10, 20, 30, 40, 50, 60, 70};

    return 0;
}
