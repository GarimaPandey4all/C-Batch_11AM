#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <string> l1 {"New Delhi", "Mumbai", "Chandigarh"};

    //cout<<l1[0]; error

    l1.push_back("Kerala");

    l1.push_front("Jammu");

    //iterator used to access the value from the list

    list <string> :: iterator p = l1.begin();

    while(p != l1.end())
    {
        cout<<*p<<endl;
        ++p;
    }

    cout<<"Total number of elements in a list are:"<<l1.size();

    return 0;
}
