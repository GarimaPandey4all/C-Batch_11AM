#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <string> l1 {"New Delhi", "Mumbai", "Chandigarh"};

    //cout<<l1[0]; error

    l1.push_back("Kerala");

    l1.push_front("Jammu");

    //iterator used to access the value from the list

    list <string> :: iterator p = l1.begin();

    while(p != l1.end())
    {
        cout<<*p<<endl;
        ++p;
    }

    cout<<"Total number of elements in a list are:"<<l1.size();

    cout<<endl;

    l1.pop_back();

    l1.pop_front();

    list <string> :: iterator p1 = l1.begin();

    while( p1 != l1.end())
    {
        cout<<*p1<<endl;
        ++p1;
    }

    cout<<"After popping the list size is:"<<l1.size();

    return 0;
}
