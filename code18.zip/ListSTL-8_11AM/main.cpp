#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <int> l1 {50, 90, 30, 10, 60};

    list <int> :: iterator p = l1.begin();

    while(p != l1.end())
    {
        cout<<*p<<endl;
        ++p;
    }

    cout<<"Total number of values in the list are:"<<l1.size()<<endl<<endl;

    l1.clear();

//    list <int> :: iterator p1 = l1.begin();
//
//    while(p1 != l1.end())
//    {
//        cout<<*p1<<endl;
//        ++p1;
//    }

    cout<<"Total number of values in the list are:"<<l1.size();

    return 0;
}
