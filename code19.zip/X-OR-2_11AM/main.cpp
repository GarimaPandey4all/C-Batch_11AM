#include <iostream>

using namespace std;

int main()
{
    int a = 5, b = 7;

    /*
        a = 5--> 0000 0101

        b = 7--> 0000 0111
        a ^ b =  0000 0010--> 2

    */

    cout<<"Before Swapping the value of a="<<a<<" and b="<<b<<endl;

    a = a ^ b;
    b = a ^ b;
    a = a ^ b;

    cout<<"After Swapping the value of a="<<a<<" and b="<<b;

    return 0;
}
