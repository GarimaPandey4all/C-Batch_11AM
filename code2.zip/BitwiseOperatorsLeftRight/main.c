#include <stdio.h>
//#include <stdlib.h>

int main()
{
    char var;

    printf("Enter value for variable:");
    scanf("%d", &var);

    //Left Shift Operator

    printf("\nLeft Shift is:%d", var << 1);

    //Right Shift Operator

    printf("\nRight Shift is:%d", var >> 1);

    return 0;
}
