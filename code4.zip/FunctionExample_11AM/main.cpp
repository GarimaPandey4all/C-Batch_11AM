#include <iostream>

using namespace std;

/*

    1. Function without arguments and without return value
    2. Function with arguments and without return value
    3. Function without arguments and with return value
    4. Funciton with arguments and with return value

    function declaration();
//Function Prototype
    return_type function_name() //function header //function definition
    {
        function body
    }

    function calling

*/


//Function without arguments and without return value

//void Showdata();
//
//int main()
//{
//    Showdata();
//
//    return 0;
//}
//
//void Showdata()
//{
//    cout<<"Hello World";
//}

//Function with arguments and without return value


//void sum(int, int);
//
//int main()
//{
//    int x, y;
//    sum(x, y);
//}
//
//
//void sum(int a, int b)
//{
//    cout<<"Enter values for a and b";
//    cin>>a>>b;
//
//    cout<<"Sum is:"<<a+b;
//}


//Function without arguments and with return value

//
//int sum();
//
//int main()
//{
//   // int result;
//    sum();
//
//    //cout<<"Sum is:"<<result;
//}
//
//
//int sum()
//{
//    int a, b;
//
//    cout<<"Enter values for a and b";
//    cin>>a>>b;
//
//    cout<<"Sum is:"<<a+b;
//
//    return 0;
//}

//Funciton with arguments and with return value

int sum(int, int);

int main()
{
   // int result;
   int x, y;
    sum(x, y);

    //cout<<"Sum is:"<<result;
}


int sum(int a, int b)
{

    cout<<"Enter values for a and b";
    cin>>a>>b;

    cout<<"Sum is:"<<a+b;

    return 0;
}
