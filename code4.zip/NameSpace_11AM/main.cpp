#include <iostream>

using namespace std;

namespace n1{

    int value = 500;

    void showdata()
    {
    cout<<"Hello World";
    }
}

//Global variable
int value = 700;

// ::--> scope resolution operator

int main()
{
    int value = 200;

    cout << "value is:"<<n1::value << endl;

    n1::showdata();

    return 0;
}
