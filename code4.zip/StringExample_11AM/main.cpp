#include <iostream>

using namespace std;

int main()
{
    string name;
    //string Firstname, Lastname;

//    cout<<"Enter your Firstname";
//    cin>>Firstname;
//
//    cout<<"Enter your Lastname";
//    cin>>Lastname;
//
//    cout << "Name is:"<<Firstname <<" "<<Lastname<< endl;


    cout<<"May i know your name:";
    getline(cin, name);

    cout<<"Name is:"<<name;

    return 0;
}
