#include <iostream>

using namespace std;

class Calculator
{
public:
    int a, b;

    void add()
    {
        cout<<"Enter any value in a & b:";
        cin>>a>>b;
        cout<<"Addition is:"<<a+b;
    }
};


int main()
{
    Calculator C1;
    C1.add();
    return 0;
}
