#include <iostream>

using namespace std;

/*
    1. function definition inside the class
    2. function definition outside the class
*/

class HelloWorld
{
public:

    void ShowData();
};

void HelloWorld::ShowData()
{
    cout<<"Hello World";
}

int main()
{
    HelloWorld h1;
    h1.ShowData();
    return 0;
}
