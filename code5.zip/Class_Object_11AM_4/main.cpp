#include <iostream>

using namespace std;

/*

    Access Specifiers:

    1. Public
    2. Private
    3. Protected

*/

class VarAssign
{
public:
    int x;
private:
    int y;
};

int main()
{
    VarAssign V1;

    V1.x=10;
    //V1.y=20;

    cout<<"X is:"<<V1.x;
    //cout<<"Y is:"<<V1.y;

    return 0;
}
