#include <iostream>

using namespace std;

class HelloWorld
{
public:

    void ShowData()
    {
       cout<<"Hello World";
    }
};

int main()
{
    HelloWorld h1;
    h1.ShowData();
    return 0;
}
