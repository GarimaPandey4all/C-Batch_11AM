#include <iostream>

using namespace std;

class MyClass
{
public:

    MyClass()
    {
        cout<<"Hello how are you?";
    }
};

int main()
{
    MyClass M1;
    MyClass M2;
    return 0;
}
