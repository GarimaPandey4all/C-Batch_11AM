#include <iostream>

using namespace std;

class MyClass
{
public:

    MyClass();
};


MyClass::MyClass()
    {
        cout<<"Hello how are you?"<<endl;
    }


int main()
{
    MyClass M1;
    MyClass M2;
    return 0;
}
