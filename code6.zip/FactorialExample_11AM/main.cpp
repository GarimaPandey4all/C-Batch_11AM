#include <iostream>

using namespace std;

int main()
{
    int fact=1, n, i;

    cout<<"Enter any number to check factorial for the same:";
    cin>>n;

    for(i=1; i<=n; i++)
    {
        fact *= i; // fact = fact * i; Assignment Operator
    }
    cout<<"Factorial of "<<n<<" is:"<<fact;

    return 0;
}
