#include <iostream>

using namespace std;

class Calculator
{
public:

    void Add(int a, int b)
    {
        cout<<"Addition of Integers:"<<a+b<<endl;
    }

    void Add(float x, float y)
    {
        cout<<"Addition of Float Numbers:"<<x+y<<endl;
    }

    void Add(double v, double w)
    {
        cout<<"Addition of Double Numbers:"<<v+w;
    }
};

int main()
{
    Calculator Cobj;
    Cobj.Add(10,20);
    Cobj.Add(10.2f, 50.8f);
    Cobj.Add(34.78, 78.90);
    return 0;
}
