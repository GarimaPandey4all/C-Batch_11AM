#include <iostream>

using namespace std;

class Func_Overloading
{
public:

    void func(int a)
    {
        cout<<"A is:"<<a<<endl;
    }
    void func(double x)
    {
        cout<<"X is"<<x<<endl;
    }
    void func(int v, int w)
    {
        cout<<"V and W is:"<<v<<"\t"<<w;
    }
};

int main()
{
    Func_Overloading Fobj;

    Fobj.func(10);
    Fobj.func(10.5);
    Fobj.func(80, 90);
    return 0;
}
