#include <iostream>

using namespace std;

class base
{
    public:
    virtual void print()
    {
        cout<<"Base Print Method:\n";
    }
    void show()
    {
        cout<<"Base Show Method";
    }
};

class derived : public base
{
    void print()
    {
        cout<<"Derived Print Method:\n";
    }
    void show()
    {
        cout<<"Derived Show Method";
    }
};

int main()
{
    base* bptr;
    derived d;
    bptr = &d;

    //runtime polymorphism: runtime binding: virtual function
    bptr->print();

    //compile time polymorphism //compile time binding *//no-virtual function
    bptr->show();

    return 0;
}
