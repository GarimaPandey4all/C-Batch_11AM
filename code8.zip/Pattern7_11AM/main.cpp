#include <iostream>

using namespace std;

int main()
{
    char i, j;

    for(i=97; i<=101; i++)
    {
        for(j=97; j<=i; j++)
        {

            //cout<<i;
            cout<<j;

        }
        cout<<endl;
    }

    return 0;
}
