#include <iostream>

using namespace std;

int main()
{
    char  i, j;

    for(i=101; i>=97; i--)
    {
        for(j=i; j>=97; j--)
        {
            //cout<<i;
            cout<<j;

        }
        cout<<endl;
    }

    return 0;
}
