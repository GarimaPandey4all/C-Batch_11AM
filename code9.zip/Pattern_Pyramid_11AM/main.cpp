#include <iostream>

using namespace std;

int main()
{
    int n, i, j;

    cout<<"Enter number of rows to print the pyramid:";
    cin>>n;

    for(i=1; i<=n; i++) //n=3
    {
        for(j=1; j<=2*n-1; j++)
        {
            if(j>=n-(i-1) && j<=n+(i-1))
            {
                //cout<<"*";
                cout<<i;
            }
            else
                cout<<" ";
        }
        cout<<endl;
    }

    return 0;
}
