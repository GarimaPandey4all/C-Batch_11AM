#include <iostream>

using namespace std;

int main()
{
    int number = 100;

    int *pnumber = NULL;

    pnumber = &number;

    cout<<"Address of="<<pnumber<<endl;

    cout<<"Value of="<<*pnumber<<endl;

    return 0;
}
