#include <iostream>

using namespace std;

int main()
{
    int number = 15;

    int result, *pnumber=NULL;

    pnumber = &number;

    result = *pnumber + 5;

    cout<<"Result is: "<<result;

    return 0;
}
