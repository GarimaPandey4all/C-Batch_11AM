#include <iostream>

using namespace std;

int main()
{
    int count=10, x;
    int *pnumber = NULL;

    pnumber = &count;

    x= *pnumber;

    cout<<"Count is: "<<count<<" X is: "<<x;

    return 0;
}
